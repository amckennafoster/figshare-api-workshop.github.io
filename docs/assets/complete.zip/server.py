from flask import Flask, send_from_directory, jsonify, request
import json
import requests

app = Flask(__name__)

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/stats', methods=['GET'])
def stats():
    url = f'https://stats.figsh.com/total/views/article/{request.args.get("item")}'
    response = requests.get(url)
    return response.json()

@app.route('/items', methods=['POST'])
def items():
    # Get the query parameter from the request
    url = "https://api.figsh.com/v2/articles/search"
    data = request.get_json()


    payload = json.dumps(data)
    headers = {'Content-Type': 'application/json'}

    response = requests.request("POST", url, headers=headers, data=payload)

    return response.json()

if __name__ == '__main__':
    app.run()