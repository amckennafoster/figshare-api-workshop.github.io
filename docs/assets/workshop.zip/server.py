from flask import Flask, render_template, request
import json
import requests

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/get', methods=['GET'])
def get_data():
    url = request.args.get('url')

    payload = {}
    headers = {}

    response = requests.request("GET", url, headers=headers, data=payload)

    return response.text

@app.route('/post', methods=['POST'])
def process_json():
    json_data = request.get_json()
    url = request.args.get('url')


    payload = json_data
    headers = {
        'Content-Type': 'application/json'
    }

    response = requests.request("POST", url, headers=headers, data=json.dumps(payload)) 

    return response.text

if __name__ == '__main__':
    app.run()